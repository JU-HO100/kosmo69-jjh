package com.mycompany.online;

import java.util.Properties;

public class A {

	public static void main(String[] args) {
		Properties prop = new Properties("username",1);
	}

}
