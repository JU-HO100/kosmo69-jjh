package com.di;

public interface HelloBean {
   public String getGreeting(String msg);
}