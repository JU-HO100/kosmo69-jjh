package com.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.kos.mvc.DeptController;
import com.kos.mvc.DeptDao;
import com.kos.mvc.DeptLogic;


public class MainForDept {
	   public static void main(String args[]) {
	      ApplicationContext context = new AnnotationConfigApplicationContext(AppCtx.class);
	      DeptController deptController = context.getBean("deptController", DeptController.class);
	      DeptLogic deptLogic = context.getBean("deptLogic", DeptLogic.class);
	      DeptDao deptDao = context.getBean("deptDao", DeptDao.class);
	      deptController.deptList();
	      deptLogic.deptList();
	      deptDao.deptList();
	      
//	      System.out.println(deptController.deptList());
	   }
	}