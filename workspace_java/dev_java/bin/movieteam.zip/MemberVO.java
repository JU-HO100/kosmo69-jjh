package movieteam;

public class MemberVO {
		private int 	MM_DEPTNO 	= 0;
		private int 	MM_HP 		= 0;
		private String 	MM_ID 		= null;
		private String 	MM_PW 		= null;
		private String 	MM_NAME 	= null;
		
		public int getMM_DEPTNO() {
			return MM_DEPTNO;
		}
		public void setMM_DEPTNO(int mM_DEPTNO) {
			MM_DEPTNO = mM_DEPTNO;
		}
		public int getMM_HP() {
			return MM_HP;
		}
		public void setMM_HP(int mM_HP) {
			MM_HP = mM_HP;
		}
		public String getMM_ID() {
			return MM_ID;
		}
		public void setMM_ID(String mM_ID) {
			MM_ID = mM_ID;
		}
		public String getMM_PW() {
			return MM_PW;
		}
		public void setMM_PW(String mM_PW) {
			MM_PW = mM_PW;
		}
		public String getMM_NAME() {
			return MM_NAME;
		}
		public void setMM_NAME(String mM_NAME) {
			MM_NAME = mM_NAME;
		}

}